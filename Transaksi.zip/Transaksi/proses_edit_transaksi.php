<?php
include '../../../koneksi.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_POST['submit'])) {
    $id_transaksi = mysqli_real_escape_string($conn, $_POST['id_transaksi']);
    $id_pembeli = mysqli_real_escape_string($conn, $_POST['id_pembeli']);
    $id_karyawan = mysqli_real_escape_string($conn, $_POST['id_karyawan']);
    $tanggal_transaksi = mysqli_real_escape_string($conn, $_POST['tanggal_transaksi']);
    $total_harga = mysqli_real_escape_string($conn, $_POST['total_harga']);

    // Validasi sederhana
    if (empty($id_pembeli) || empty($id_karyawan) || empty($tanggal_transaksi) || $total_harga === '') {
        die("Semua field wajib diisi.");
    }

    // Update transaksi
    $query = "
        UPDATE transaksi 
        SET id_pembeli = '$id_pembeli',
            id_karyawan = '$id_karyawan',
            tanggal_transaksi = '$tanggal_transaksi',
            total_harga = '$total_harga'
        WHERE id_transaksi = '$id_transaksi'
    ";

    if (mysqli_query($conn, $query)) {
        header("Location: index.php?status=update_sukses");
        exit;
    } else {
        die("Gagal update transaksi: " . mysqli_error($conn));
    }

} else {
    die("Form belum dikirim.");
}
?>
