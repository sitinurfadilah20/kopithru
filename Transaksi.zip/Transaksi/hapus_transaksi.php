<?php
include '../../../koneksi.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_GET['id'])) {
    die("ID transaksi tidak ditemukan.");
}

$id_transaksi = $_GET['id'];

// Hapus transaksi
$query = "DELETE FROM transaksi WHERE id_transaksi = '$id_transaksi'";
if (mysqli_query($conn, $query)) {
    header("Location: index.php?status=hapus_sukses");
    exit;
} else {
    die("Gagal menghapus transaksi: " . mysqli_error($conn));
}
?>
