<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../../../includes/navbar.php';
include '../../../koneksi.php';

// Ambil data transaksi + relasi karyawan dan pembeli
$query = "
    SELECT 
        t.id_transaksi,
        t.tanggal_transaksi,
        k.Nama_karyawan,
        p.Nama_pembeli,
        t.total_harga
    FROM transaksi t
    JOIN karyawan k ON t.id_karyawan = k.Id_karyawan
    JOIN pembeli p ON t.id_pembeli = p.Id_pembeli
    ORDER BY t.id_transaksi DESC
";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Data Transaksi - Kopi Thru</title>
<link rel="stylesheet" href="../../../assets/css/style.css">
<style>
    body { font-family: "Poppins", sans-serif; background-color: #e8f4ff; color: #333; margin: 20px; }
    h2 { text-align: center; color: #007bff; }
    table { width: 90%; margin: 20px auto; border-collapse: collapse; background: #fff; border-radius: 10px; overflow: hidden; }
    th, td { border: 1px solid #ccc; padding: 10px; text-align: center; }
    th { background: #007bff; color: white; }
    tr:nth-child(even) { background: #f2f9ff; }
    .btn { padding: 8px 12px; border-radius: 5px; color: white; text-decoration: none; }
    .btn-add { background: #28a745; display: block; width: 200px; margin: 10px auto; text-align: center; }
    .btn-edit { background: #007bff; }
    .btn-delete { background: #dc3545; }
</style>
</head>
<body>
    <h2>Daftar Transaksi ☕</h2>
    <a href="tambah_transaksi.php" class="btn btn-add">+ Tambah Transaksi</a>

    <table>
        <thead>
            <tr>
                <th>ID Transaksi</th>
                <th>Tanggal Transaksi</th>
                <th>Nama Karyawan</th>
                <th>Nama Pembeli</th>
                <th>Total Harga</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result && mysqli_num_rows($result) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?= $row['id_transaksi']; ?></td>
                        <td><?= $row['tanggal_transaksi']; ?></td>
                        <td><?= htmlspecialchars($row['Nama_karyawan']); ?></td>
                        <td><?= htmlspecialchars($row['Nama_pembeli']); ?></td>
                        <td><?= number_format($row['total_harga'], 0, ',', '.'); ?></td>
                        <td>
                            <a href="edit_transaksi_form.php?id=<?= $row['id_transaksi']; ?>" class="btn btn-edit">Edit</a>
                            <a href="hapus_transaksi.php?id=<?= $row['id_transaksi']; ?>" class="btn btn-delete" onclick="return confirm('Yakin ingin hapus transaksi ini?')">Hapus</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="6">Belum ada transaksi.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>