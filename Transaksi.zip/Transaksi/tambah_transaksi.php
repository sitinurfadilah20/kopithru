<?php 
include '../../../koneksi.php';
include '../../../includes/navbar.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Ambil semua data karyawan, pembeli, dan menu dari database
$karyawan = mysqli_query($conn, "SELECT * FROM karyawan");
$pembeli  = mysqli_query($conn, "SELECT * FROM pembeli");
$menu     = mysqli_query($conn, "SELECT * FROM menu");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Tambah Transaksi | Kopi Thru</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../../../assets/css/style.css">
<style>
    body { font-family: "Poppins", sans-serif; background-color: #e8f4ff; padding: 20px; }
    form { background: #fff; padding: 20px; border-radius: 10px; width: 600px; margin: auto; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
    h2 { text-align: center; color: #007bff; margin-bottom: 20px; }
    label { display: block; margin-top: 10px; font-weight: 500; }
    input, select { width: 100%; padding: 8px; margin-top: 5px; border-radius: 5px; border: 1px solid #ccc; }
    .menu-item { display: flex; align-items: center; margin-top: 5px; }
    .menu-item img { width: 60px; height: 40px; object-fit: cover; margin-right: 10px; border-radius: 5px; border: 1px solid #ccc; }
    button { background: #007bff; color: white; border: none; padding: 10px; width: 100%; margin-top: 15px; border-radius: 8px; }
    button:hover { background: #0056b3; cursor: pointer; }
</style>
</head>
<body>

<h2>Tambah Transaksi</h2>

<form action="proses_tambah_transaksi.php" method="POST">
    <label for="tanggal_transaksi">Tanggal Transaksi:</label>
    <input type="date" id="tanggal_transaksi" name="tanggal_transaksi" required>

    <label for="id_karyawan">Karyawan:</label>
    <select id="id_karyawan" name="id_karyawan" required>
        <option value="">-- Pilih Karyawan --</option>
        <?php while ($k = mysqli_fetch_assoc($karyawan)) : ?>
            <option value="<?= $k['Id_karyawan']; ?>"><?= $k['Nama_karyawan']; ?></option>
        <?php endwhile; ?>
    </select>

    <label for="id_pembeli">Pembeli:</label>
    <select id="id_pembeli" name="id_pembeli" required>
        <option value="">-- Pilih Pembeli --</option>
        <?php while ($p = mysqli_fetch_assoc($pembeli)) : ?>
            <option value="<?= $p['Id_pembeli']; ?>"><?= $p['Nama_pembeli']; ?></option>
        <?php endwhile; ?>
    </select>

    <label>Menu yang dipilih:</label>
    <?php while ($m = mysqli_fetch_assoc($menu)) : ?>
        <?php 
            $gambar = !empty($m['gambar']) ? "../../../".$m['gambar'] : "../../../assets/images/kopi.jpg"; 
        ?>
        <div class="menu-item">
            <input type="checkbox" name="menu[]" value="<?= $m['Id_menu']; ?>" id="menu_<?= $m['Id_menu']; ?>">
            <img src="<?= htmlspecialchars($gambar); ?>" alt="<?= htmlspecialchars($m['Nama_Menu']); ?>">
            <label for="menu_<?= $m['Id_menu']; ?>">
                <?= htmlspecialchars($m['Nama_Menu']); ?> (Rp <?= number_format($m['Harga'],0,',','.'); ?>)
            </label>
        </div>
    <?php endwhile; ?>

    <button type="submit" name="submit">Simpan Transaksi</button>
</form>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>